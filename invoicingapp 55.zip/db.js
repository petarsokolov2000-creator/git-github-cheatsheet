import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new DatabaseSync(path.join(__dirname, 'data', 'invoices.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    company_name TEXT NOT NULL DEFAULT '',
    company_address TEXT NOT NULL DEFAULT '',
    company_tax_id TEXT NOT NULL DEFAULT '',
    company_bank_account TEXT NOT NULL DEFAULT '',
    company_phone TEXT NOT NULL DEFAULT '',
    company_bank_name TEXT NOT NULL DEFAULT '',
    company_logo TEXT NOT NULL DEFAULT '',
    payment_terms_note TEXT NOT NULL DEFAULT '',
    default_vat_rate REAL NOT NULL DEFAULT 18,
    is_vat_payer INTEGER NOT NULL DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    name_lower TEXT NOT NULL DEFAULT '',
    address TEXT,
    place TEXT,
    tax_id TEXT,
    mb TEXT,
    phone TEXT,
    email TEXT,
    contact_name TEXT,
    contact_phone TEXT,
    source TEXT NOT NULL DEFAULT 'manual',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE UNIQUE INDEX IF NOT EXISTS idx_clients_tax_id ON clients(tax_id) WHERE tax_id IS NOT NULL AND tax_id != '';

  CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_number TEXT UNIQUE NOT NULL,
    issue_date TEXT NOT NULL,
    due_date TEXT,
    client_id INTEGER REFERENCES clients(id),
    client_name TEXT NOT NULL,
    client_address TEXT,
    client_tax_id TEXT,
    client_mb TEXT,
    client_contact TEXT,
    reference TEXT,
    notes TEXT,
    vat_rate REAL NOT NULL DEFAULT 18,
    gross_amount REAL NOT NULL DEFAULT 0,
    discount_amount REAL NOT NULL DEFAULT 0,
    subtotal REAL NOT NULL,
    vat_amount REAL NOT NULL,
    total REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'booked',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    name_lower TEXT NOT NULL DEFAULT '',
    vat_rate REAL NOT NULL DEFAULT 18,
    type TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_articles_name_lower ON articles(name_lower);

  CREATE TABLE IF NOT EXISTS invoice_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    item_code TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL,
    unit TEXT NOT NULL DEFAULT 'бр',
    quantity REAL NOT NULL,
    unit_price REAL NOT NULL,
    discount_percent REAL NOT NULL DEFAULT 0,
    vat_rate REAL NOT NULL DEFAULT 18,
    line_gross REAL NOT NULL DEFAULT 0,
    line_discount REAL NOT NULL DEFAULT 0,
    line_net REAL NOT NULL DEFAULT 0,
    line_vat REAL NOT NULL DEFAULT 0,
    line_total REAL NOT NULL
  );
`);

function ensureColumns(table, columns) {
  const existing = new Set(db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name));
  for (const [name, definition] of Object.entries(columns)) {
    if (!existing.has(name)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${definition}`);
  }
}

ensureColumns('invoices', {
  client_id: 'INTEGER REFERENCES clients(id)',
  client_mb: 'TEXT',
  client_contact: 'TEXT',
  reference: 'TEXT',
  gross_amount: 'REAL NOT NULL DEFAULT 0',
  discount_amount: 'REAL NOT NULL DEFAULT 0',
});

ensureColumns('settings', {
  company_phone: "TEXT NOT NULL DEFAULT ''",
  company_bank_name: "TEXT NOT NULL DEFAULT ''",
  company_logo: "TEXT NOT NULL DEFAULT ''",
  payment_terms_note: "TEXT NOT NULL DEFAULT ''",
  is_vat_payer: 'INTEGER NOT NULL DEFAULT 1',
});

const itemColumnsBefore = new Set(db.prepare('PRAGMA table_info(invoice_items)').all().map((c) => c.name));
ensureColumns('invoice_items', {
  item_code: "TEXT NOT NULL DEFAULT ''",
  unit: "TEXT NOT NULL DEFAULT 'бр'",
  discount_percent: 'REAL NOT NULL DEFAULT 0',
  vat_rate: 'REAL NOT NULL DEFAULT 18',
  line_gross: 'REAL NOT NULL DEFAULT 0',
  line_discount: 'REAL NOT NULL DEFAULT 0',
  line_net: 'REAL NOT NULL DEFAULT 0',
  line_vat: 'REAL NOT NULL DEFAULT 0',
});
if (!itemColumnsBefore.has('line_gross')) {
  // Пресметува ги новите распределени полиња за ставки создадени пред оваа промена
  // (претходно постоеше само вкупен износ без ДДВ, без попуст и без стапка по ставка).
  for (const item of db.prepare('SELECT * FROM invoice_items').all()) {
    const invoice = db.prepare('SELECT vat_rate FROM invoices WHERE id = ?').get(item.invoice_id);
    const vatRate = invoice ? invoice.vat_rate : 18;
    const gross = Math.round(item.quantity * item.unit_price * 100) / 100;
    const vat = Math.round(gross * (vatRate / 100) * 100) / 100;
    const total = Math.round((gross + vat) * 100) / 100;
    db.prepare(
      `UPDATE invoice_items SET vat_rate = ?, line_gross = ?, line_discount = 0, line_net = ?, line_vat = ?, line_total = ?
       WHERE id = ?`
    ).run(vatRate, gross, gross, vat, total, item.id);
  }
}
// Постоечки фактури немаа збирен gross_amount на ниво на фактура (пред попустот по ставка да постоеше).
// Идемпотентно: штом веднаш се пополни, повеќе нема да е 0.
for (const invoice of db.prepare('SELECT id FROM invoices WHERE gross_amount = 0 AND subtotal > 0').all()) {
  const sum = db.prepare('SELECT COALESCE(SUM(line_gross), 0) AS gross FROM invoice_items WHERE invoice_id = ?').get(invoice.id);
  db.prepare('UPDATE invoices SET gross_amount = ? WHERE id = ?').run(sum.gross, invoice.id);
}

const clientColumns = new Set(db.prepare('PRAGMA table_info(clients)').all().map((c) => c.name));
if (!clientColumns.has('name_lower')) {
  db.exec("ALTER TABLE clients ADD COLUMN name_lower TEXT NOT NULL DEFAULT ''");
}
ensureColumns('clients', {
  contact_name: 'TEXT',
  contact_phone: 'TEXT',
});
// SQLite's LIKE only case-folds ASCII, so Cyrillic search needs a JS-lowercased column on both sides.
for (const row of db.prepare('SELECT id, name FROM clients WHERE name_lower = ?').all('')) {
  db.prepare('UPDATE clients SET name_lower = ? WHERE id = ?').run(row.name.toLowerCase(), row.id);
}
db.exec('CREATE INDEX IF NOT EXISTS idx_clients_name_lower ON clients(name_lower)');

// Еднократно: ако артиклите-каталогот е празен, го пополнува со досегашните различни
// артикли од веќе издадените фактури, со прогресивна шифра (000001, 000002, ...).
if (db.prepare('SELECT COUNT(*) AS c FROM articles').get().c === 0) {
  const rows = db.prepare('SELECT description, vat_rate FROM invoice_items ORDER BY id ASC').all();
  const seen = new Map();
  for (const row of rows) {
    if (!row.description) continue;
    const key = row.description.toLowerCase();
    if (!seen.has(key)) seen.set(key, row);
  }
  let seq = 1;
  const insertArticle = db.prepare('INSERT INTO articles (code, name, name_lower, vat_rate, type) VALUES (?, ?, ?, ?, ?)');
  for (const row of seen.values()) {
    insertArticle.run(String(seq).padStart(5, '0'), row.description, row.description.toLowerCase(), row.vat_rate || 18, '');
    seq++;
  }
}

if (db.prepare('SELECT COUNT(*) AS c FROM settings').get().c === 0) {
  db.prepare(
    `INSERT INTO settings (id, company_name, company_address, company_tax_id, company_bank_account, default_vat_rate)
     VALUES (1, '', '', '', '', 18)`
  ).run();
}

export default db;
