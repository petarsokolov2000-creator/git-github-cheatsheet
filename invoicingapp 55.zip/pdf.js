/* Генерирање PDF без надворешни пакети.
   Го користи Chrome или Edge што веќе е инсталиран на компјутерот, во „headless" режим,
   за да ја отпечати страницата /print.html во PDF. Така PDF-от е со вистински текст
   (може да се пребарува и копира), кирилицата работи, а апликацијата останува мала. */

import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const WINDOWS_CANDIDATES = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe'),
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
];

const MAC_CANDIDATES = [
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
];

const LINUX_CANDIDATES = [
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
  '/usr/bin/microsoft-edge',
];

let cachedBrowser;

export function findBrowser() {
  if (cachedBrowser !== undefined) return cachedBrowser;
  const candidates =
    process.platform === 'win32' ? WINDOWS_CANDIDATES : process.platform === 'darwin' ? MAC_CANDIDATES : LINUX_CANDIDATES;
  cachedBrowser = candidates.find((p) => p && fs.existsSync(p)) || null;
  return cachedBrowser;
}

export async function renderPdf(url) {
  const browser = findBrowser();
  if (!browser) {
    throw new Error(
      'Не е пронајден Google Chrome или Microsoft Edge на овој компјутер, а е потребен за да се создаде PDF. ' +
        'Наместо тоа користете „Печати" и изберете „Save as PDF".'
    );
  }

  const workDir = fs.mkdtempSync(path.join(os.tmpdir(), 'fakturi-pdf-'));
  const pdfPath = path.join(workDir, 'faktura.pdf');
  const profileDir = path.join(workDir, 'profile');

  const args = [
    '--headless',
    '--disable-gpu',
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-extensions',
    '--disable-background-networking',
    `--user-data-dir=${profileDir}`,
    '--no-pdf-header-footer',
    '--virtual-time-budget=8000',
    `--print-to-pdf=${pdfPath}`,
    url,
  ];

  await new Promise((resolve, reject) => {
    const child = spawn(browser, args, { windowsHide: true });
    let stderr = '';
    const timer = setTimeout(() => {
      child.kill();
      reject(new Error('Создавањето на PDF трае предолго и беше прекинато.'));
    }, 45000);

    child.stderr.on('data', (d) => { stderr += d.toString(); });
    child.on('error', (err) => { clearTimeout(timer); reject(err); });
    child.on('close', () => {
      clearTimeout(timer);
      if (fs.existsSync(pdfPath)) resolve();
      else reject(new Error('Прелистувачот не создаде PDF. ' + stderr.slice(-400)));
    });
  });

  const buffer = fs.readFileSync(pdfPath);
  fs.rmSync(workDir, { recursive: true, force: true });
  return buffer;
}
