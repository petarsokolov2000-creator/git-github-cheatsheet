/* Заеднички код за документот на фактурата.
   Се вчитува и од главната апликација (index.html) и од страницата за PDF (print.html),
   за да изгледаат идентично прегледот, печатењето и преземениот PDF. */

const fmt = new Intl.NumberFormat('mk-MK', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const money = (n) => `${fmt.format(Number(n) || 0)} МКД`;

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ---- Износ со зборови (македонски) ----
const MK_ONES = ['', 'еден', 'два', 'три', 'четири', 'пет', 'шест', 'седум', 'осум', 'девет'];
const MK_ONES_F = ['', 'една', 'две', 'три', 'четири', 'пет', 'шест', 'седум', 'осум', 'девет'];
const MK_TEENS = ['десет', 'единаесет', 'дванаесет', 'тринаесет', 'четиринаесет', 'петнаесет', 'шеснаесет', 'седумнаесет', 'осумнаесет', 'деветнаесет'];
const MK_TENS = ['', '', 'дваесет', 'триесет', 'четириесет', 'педесет', 'шеесет', 'седумдесет', 'осумдесет', 'деведесет'];
const MK_HUNDREDS = ['', 'сто', 'двесте', 'триста', 'четиристотини', 'петстотини', 'шестотини', 'седумстотини', 'осумстотини', 'деветстотини'];
const MK_SCALES = [
  { div: 1000000000, one: 'милијарда', few: 'милијарди', feminine: false },
  { div: 1000000, one: 'милион', few: 'милиони', feminine: false },
  { div: 1000, one: 'илјада', few: 'илјади', feminine: true },
];

function threeDigitWordsMk(n, feminine) {
  const h = Math.floor(n / 100);
  const rem = n % 100;
  const segments = [];
  if (h > 0) segments.push(MK_HUNDREDS[h]);
  if (rem >= 10 && rem < 20) {
    segments.push(MK_TEENS[rem - 10]);
  } else {
    const t = Math.floor(rem / 10);
    const o = rem % 10;
    const onesWords = feminine ? MK_ONES_F : MK_ONES;
    if (t > 0 && o > 0) segments.push(`${MK_TENS[t]} и ${onesWords[o]}`);
    else if (t > 0) segments.push(MK_TENS[t]);
    else if (o > 0) segments.push(onesWords[o]);
  }
  return segments.join(' ');
}

function numberToMacedonianWords(n) {
  if (n === 0) return 'нула';
  let remaining = n;
  const parts = [];
  for (const scale of MK_SCALES) {
    const count = Math.floor(remaining / scale.div);
    if (count > 0) {
      const countWords = count === 1 ? '' : threeDigitWordsMk(count, scale.feminine);
      const scaleWord = count === 1 ? scale.one : scale.few;
      parts.push(countWords ? `${countWords} ${scaleWord}` : scaleWord);
      remaining -= count * scale.div;
    }
  }
  if (remaining > 0) parts.push(threeDigitWordsMk(remaining, false));
  return parts.join(' ');
}

function amountToMacedonianWords(amount) {
  const num = Math.round((Number(amount) || 0) * 100) / 100;
  const whole = Math.floor(num);
  const cents = Math.round((num - whole) * 100);
  let text = `${numberToMacedonianWords(whole)} ${whole === 1 ? 'денар' : 'денари'}`;
  if (cents > 0) text += ` и ${cents} ${cents === 1 ? 'ден' : 'дени'}`;
  return text.charAt(0).toUpperCase() + text.slice(1);
}

// ---- Изглед на документот ----
function buildInvoiceDocHtml(inv, settings) {
  const logoHtml = settings.company_logo
    ? `<div class="doc-logo"><img src="${settings.company_logo}" alt="Лого" /></div>`
    : '';

  const bankLine = [settings.company_bank_account, settings.company_bank_name].filter(Boolean).join('; ');
  const vatBreakdown = inv.vatBreakdown || [];

  return `
    <div class="invoice-doc">
      <div class="doc-header">
        <div class="doc-issuer">
          ${logoHtml}
          <div>
            <h3>${escapeHtml(settings.company_name || 'Вашата компанија')}</h3>
            <div>${escapeHtml(settings.company_address || '')}</div>
            ${settings.company_phone ? `<div>Тел: ${escapeHtml(settings.company_phone)}</div>` : ''}
            <div>ЕДБ: ${escapeHtml(settings.company_tax_id || '')}</div>
            ${bankLine ? `<div>Жиро с-ка: ${escapeHtml(bankLine)}</div>` : ''}
          </div>
        </div>
      </div>

      <div class="doc-title"><h2>ФАКТУРА БР: ${escapeHtml(inv.invoice_number)}</h2></div>

      <div class="doc-meta-row">
        <div>
          <div>Датум: ${escapeHtml(inv.issue_date)}</div>
          <div>Валута: ${escapeHtml(inv.due_date || '-')}</div>
          ${inv.reference ? `<div>Референца: ${escapeHtml(inv.reference)}</div>` : ''}
        </div>
        <div class="doc-meta-right">
          <div><strong>${escapeHtml(inv.client_name)}</strong></div>
          ${inv.client_address ? `<div>${escapeHtml(inv.client_address)}</div>` : ''}
          ${inv.client_tax_id ? `<div>ЕДБ: ${escapeHtml(inv.client_tax_id)}</div>` : ''}
          ${inv.client_mb ? `<div>МБ: ${escapeHtml(inv.client_mb)}</div>` : ''}
          ${inv.client_contact ? `<div>Контакт: ${escapeHtml(inv.client_contact)}</div>` : ''}
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th>Шифра</th>
            <th>Артикал</th>
            <th>Ед.М</th>
            <th class="num">Кол.</th>
            <th class="num">Цена без ДДВ</th>
            <th class="num">Рабат %</th>
            <th class="num">ДДВ %</th>
            <th class="num">Износ без ДДВ</th>
            <th class="num">Износ со ДДВ</th>
          </tr>
        </thead>
        <tbody>
          ${inv.items
            .map(
              (it) => `<tr>
                <td>${escapeHtml(it.item_code || '')}</td>
                <td>${escapeHtml(it.description)}</td>
                <td>${escapeHtml(it.unit || 'бр')}</td>
                <td class="num">${fmt.format(it.quantity)}</td>
                <td class="num">${money(it.unit_price)}</td>
                <td class="num">${fmt.format(it.discount_percent)}%</td>
                <td class="num">${fmt.format(it.vat_rate)}%</td>
                <td class="num">${money(it.line_net)}</td>
                <td class="num">${money(it.line_total)}</td>
              </tr>`
            )
            .join('')}
        </tbody>
      </table>

      <div class="doc-summary">
        <div class="doc-vat-breakdown">
          ${
            vatBreakdown.length > 0
              ? `<table>
                  <thead><tr><th>Данок</th><th>Основица за ДДВ</th><th>ДДВ</th></tr></thead>
                  <tbody>
                    ${vatBreakdown
                      .map((v) => `<tr><td>${fmt.format(v.vat_rate)}%</td><td>${money(v.base)}</td><td>${money(v.vat)}</td></tr>`)
                      .join('')}
                  </tbody>
                </table>`
              : ''
          }
        </div>
        <div class="doc-totals">
          <div><span>Износ без ДДВ:</span> <span>${money(inv.gross_amount)}</span></div>
          <div><span>Рабат:</span> <span>${money(inv.discount_amount)}</span></div>
          <div><span>Износ ДДВ:</span> <span>${money(inv.vat_amount)}</span></div>
          <div class="grand"><span>ЗА НАПЛАТА:</span> <span>${money(inv.total)}</span></div>
        </div>
      </div>

      <div class="doc-words">Со зборови: ${amountToMacedonianWords(inv.total)}</div>

      ${inv.notes ? `<p><strong>Забелешка:</strong> ${escapeHtml(inv.notes)}</p>` : ''}
      ${settings.payment_terms_note ? `<div class="doc-terms">${escapeHtml(settings.payment_terms_note)}</div>` : ''}
    </div>
  `;
}

/* Логото добива иста висина како блокот со податоци за фирмата (симетрично заглавие). */
function syncLogoSizeToIssuerTextIn(root) {
  const logo = root.querySelector('.doc-logo');
  const issuer = root.querySelector('.doc-issuer');
  if (!logo || !issuer) return;
  const textCol = issuer.querySelector(':scope > div:last-child');
  if (!textCol) return;

  logo.style.width = '';
  logo.style.height = '';
  const size = Math.round(Math.min(160, Math.max(70, textCol.getBoundingClientRect().height)));
  logo.style.width = `${size}px`;
  logo.style.height = `${size}px`;
}
