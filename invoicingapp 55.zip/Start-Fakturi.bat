@echo off
setlocal
cd /d "%~dp0"
title Fakturiranje - server (ne zatvarajte go ovoj prozorec)

rem Osvezhi ja PATH promenlivata direktno od registarot, za da se najde node
rem i vednash po instalacija na Node.js, bez restart na kompjuterot.
for /f "usebackq tokens=2,*" %%A in (`reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul`) do set "SysPath=%%B"
for /f "usebackq tokens=2,*" %%A in (`reg query "HKCU\Environment" /v Path 2^>nul`) do set "UserPath=%%B"
set "PATH=%SysPath%;%UserPath%;%PATH%"

echo.
echo   ==========================================
echo      F A K T U R I R A N J E
echo   ==========================================
echo.

rem ---- Ako aplikacijata veke raboti, samo otvori ja ----
rem (Ne se koristi netstat zatoa shto na neangliski Windows pishuva prevedeno
rem  "ABHOEREN"/"ODSLUSHUVANJE" namesto "LISTENING". Ovaa proverka e nezavisna od jazikot.)
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $c = New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1',3000); $c.Close(); exit 0 } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 (
  echo   Aplikacijata veke raboti.
  echo   Se otvora vo pregleduvachot...
  start "" http://localhost:3000
  ping -n 3 127.0.0.1 >nul
  exit /b 0
)

rem ---- Proveri dali ima Node.js ----
where node >nul 2>nul
if errorlevel 1 (
  echo   Node.js ne e pronajden na ovoj kompjuter.
  echo.
  echo   1^) Otvorete https://nodejs.org
  echo   2^) Prezemete ja verzijata oznachena so "LTS" i instalirajte ja
  echo   3^) Povtorno kliknete dvapati na "Start-Fakturi.bat"
  echo.
  pause
  exit /b 1
)

rem ---- Paketite se vklucheni vo ova pakuvanje; instaliraj samo ako fali neshto ----
if not exist "node_modules\express\package.json" (
  echo   Se podgotvuvaat potrebnite paketi ^(samo prv pat^)...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo   Ne uspea podgotovkata na paketite. Proverete ja internet vrskata.
    echo.
    pause
    exit /b 1
  )
)

rem ---- Otvori go pregleduvachot tochno koga serverot ke bide spremen ----
start "" /b powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "for($i=0;$i -lt 90;$i++){ try { Invoke-WebRequest -UseBasicParsing -Uri 'http://localhost:3000' -TimeoutSec 2 | Out-Null; Start-Process 'http://localhost:3000'; break } catch { Start-Sleep -Milliseconds 400 } }"

echo   Serverot se startuva...
echo   Pregleduvachot ke se otvori avtomatski za nekolku sekundi.
echo.
echo   VAZHNO: ostavete go ovoj prozorec otvoren dodeka ja koristite aplikacijata.
echo   Koga ke zavrshite - samo zatvorete go ovoj prozorec.
echo.
echo   ------------------------------------------
echo.

node server.js

echo.
echo   Serverot e zapren.
echo.
pause
