const SEARCH_URL = 'https://ujp.gov.mk/mk/prebaruvanje_pravni_lica/prebaruvaj';
const DETAIL_URL = 'https://ujp.gov.mk/mk/prebaruvanje_pravni_lica/prikazi';
const HEADERS = { 'User-Agent': 'Mozilla/5.0 (compatible; invoicing-app/1.0)' };
const TIMEOUT_MS = 6000;

async function fetchWithTimeout(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { headers: HEADERS, signal: controller.signal });
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

function decodeEntities(str) {
  return str
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .trim();
}

export async function searchCompanies(query) {
  const url = `${SEARCH_URL}?pravno_lice=${encodeURIComponent(query)}`;
  const html = await fetchWithTimeout(url);
  const results = [];
  const re = /<a href="\/mk\/prebaruvanje_pravni_lica\/prikazi\?edb=([^"]+)"[^>]*>([^<]*)<\/a>/g;
  let match;
  while ((match = re.exec(html)) !== null) {
    results.push({ edb: match[1], name: decodeEntities(match[2]) });
  }
  return results.slice(0, 15);
}

export async function getCompanyDetails(edb) {
  const url = `${DETAIL_URL}?edb=${encodeURIComponent(edb)}`;
  const html = await fetchWithTimeout(url);
  const fields = {};
  const re = /<td>([^<]+)<\/td>\s*<td>([^<]*)<\/td>/g;
  let match;
  while ((match = re.exec(html)) !== null) {
    fields[decodeEntities(match[1])] = decodeEntities(match[2]);
  }
  if (!fields['Назив']) return null;
  return {
    name: fields['Назив'] || '',
    legal_form: fields['Правна форма'] || '',
    activity: fields['Дејност'] || '',
    edb: fields['ЕДБ'] || edb,
    mb: fields['Матичен број'] || '',
    address: fields['Адреса'] || '',
    place: fields['Место'] || '',
    phone: fields['Телефон'] || '',
    giro_account: fields['Жиро сметка'] || '',
    depository_bank: fields['Депонент банка'] || '',
  };
}
