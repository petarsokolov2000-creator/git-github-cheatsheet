import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import db from './db.js';
import { searchCompanies, getCompanyDetails } from './ujp.js';
import { renderPdf } from './pdf.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '5mb' })); // поголем лимит поради логото на компанијата (base64 слика)
app.use(express.static(path.join(__dirname, 'public')));

function nextInvoiceNumber() {
  const year = new Date().getFullYear();
  const prefix = `ФАК-${year}-`;
  const row = db
    .prepare(
      `SELECT invoice_number FROM invoices
       WHERE invoice_number LIKE ?
       ORDER BY id DESC LIMIT 1`
    )
    .get(`${prefix}%`);
  let seq = 1;
  if (row) {
    const parts = row.invoice_number.split('-');
    seq = parseInt(parts[parts.length - 1], 10) + 1;
  }
  return `${prefix}${String(seq).padStart(4, '0')}`;
}

// ---- Settings ----

app.get('/api/settings', (req, res) => {
  const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get();
  res.json(settings);
});

app.put('/api/settings', (req, res) => {
  const {
    company_name = '',
    company_address = '',
    company_tax_id = '',
    company_bank_account = '',
    company_phone = '',
    company_bank_name = '',
    company_logo = '',
    payment_terms_note = '',
    default_vat_rate = 18,
    is_vat_payer = true,
  } = req.body || {};

  db.prepare(
    `UPDATE settings SET company_name = ?, company_address = ?, company_tax_id = ?,
     company_bank_account = ?, company_phone = ?, company_bank_name = ?, company_logo = ?,
     payment_terms_note = ?, default_vat_rate = ?, is_vat_payer = ? WHERE id = 1`
  ).run(
    company_name,
    company_address,
    company_tax_id,
    company_bank_account,
    company_phone,
    company_bank_name,
    company_logo,
    payment_terms_note,
    Number(default_vat_rate),
    is_vat_payer ? 1 : 0
  );

  res.json(db.prepare('SELECT * FROM settings WHERE id = 1').get());
});

// ---- Clients (local database, built up from УЈП lookups and manual entries) ----

function upsertClient({
  name,
  address = '',
  place = '',
  tax_id = '',
  mb = '',
  phone = '',
  email = '',
  contact_name = '',
  contact_phone = '',
  source = 'manual',
}) {
  const nameLower = name.toLowerCase();
  let existing = null;
  if (tax_id) {
    existing = db.prepare('SELECT * FROM clients WHERE tax_id = ?').get(tax_id);
  }
  if (!existing && name) {
    existing = db.prepare('SELECT * FROM clients WHERE name_lower = ? AND (tax_id IS NULL OR tax_id = ?)').get(nameLower, tax_id || '');
  }

  if (existing) {
    db.prepare(
      `UPDATE clients SET name = ?, name_lower = ?, address = ?, place = ?, tax_id = ?, mb = ?,
       phone = COALESCE(NULLIF(?, ''), phone), email = COALESCE(NULLIF(?, ''), email),
       contact_name = COALESCE(NULLIF(?, ''), contact_name), contact_phone = COALESCE(NULLIF(?, ''), contact_phone)
       WHERE id = ?`
    ).run(name, nameLower, address, place, tax_id || null, mb, phone, email, contact_name, contact_phone, existing.id);
    return db.prepare('SELECT * FROM clients WHERE id = ?').get(existing.id);
  }

  const result = db
    .prepare(
      `INSERT INTO clients (name, name_lower, address, place, tax_id, mb, phone, email, contact_name, contact_phone, source)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(name, nameLower, address, place, tax_id || null, mb, phone, email, contact_name, contact_phone, source);
  return db.prepare('SELECT * FROM clients WHERE id = ?').get(result.lastInsertRowid);
}

app.get('/api/clients', (req, res) => {
  const q = (req.query.q || '').trim().toLowerCase();
  if (q) {
    const rows = db
      .prepare(`SELECT * FROM clients WHERE name_lower LIKE ? ORDER BY name ASC LIMIT 15`)
      .all(`%${q}%`);
    return res.json(rows);
  }
  res.json(db.prepare('SELECT * FROM clients ORDER BY name ASC').all());
});

app.post('/api/clients', (req, res) => {
  const { name, address = '', place = '', tax_id = '', mb = '', phone = '', email = '', contact_name = '', contact_phone = '' } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Името на клиентот е задолжително' });
  const client = upsertClient({ name, address, place, tax_id, mb, phone, email, contact_name, contact_phone, source: 'manual' });
  res.status(201).json(client);
});

app.put('/api/clients/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM clients WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Клиентот не е пронајден' });
  const { name, address = '', place = '', tax_id = '', mb = '', phone = '', email = '', contact_name = '', contact_phone = '' } = req.body || {};
  const finalName = name || existing.name;
  db.prepare(
    `UPDATE clients SET name = ?, name_lower = ?, address = ?, place = ?, tax_id = ?, mb = ?, phone = ?, email = ?,
     contact_name = ?, contact_phone = ? WHERE id = ?`
  ).run(finalName, finalName.toLowerCase(), address, place, tax_id || null, mb, phone, email, contact_name, contact_phone, req.params.id);
  res.json(db.prepare('SELECT * FROM clients WHERE id = ?').get(req.params.id));
});

app.delete('/api/clients/:id', (req, res) => {
  db.prepare('DELETE FROM clients WHERE id = ?').run(req.params.id);
  res.status(204).end();
});

// ---- Articles (артикли) — прогресивна шифра 000001, 000002, ... ----

const ARTICLE_TYPES = ['Трговска стока', 'Репроматеријал', 'Готов производ', 'Услуга'];

function nextArticleCode() {
  const row = db.prepare('SELECT code FROM articles ORDER BY CAST(code AS INTEGER) DESC LIMIT 1').get();
  const next = row ? parseInt(row.code, 10) + 1 : 1;
  return String(next).padStart(5, '0');
}

function upsertArticle({ code = '', name, vat_rate, type = '' }) {
  const nameLower = name.toLowerCase();
  // Ако е внесена шифра што веќе постои, тоа е упатување на постоечкиот артикал - не го менуваме
  // неговото име според тековниот ред на фактурата, само стапката/видот ако се дадени.
  let existing = code ? db.prepare('SELECT * FROM articles WHERE code = ?').get(code) : null;
  if (!existing) {
    existing = db.prepare('SELECT * FROM articles WHERE name_lower = ?').get(nameLower);
  }

  if (existing) {
    if (vat_rate !== undefined && vat_rate !== null) {
      db.prepare('UPDATE articles SET vat_rate = ? WHERE id = ?').run(Number(vat_rate), existing.id);
    }
    if (type) {
      db.prepare('UPDATE articles SET type = ? WHERE id = ?').run(type, existing.id);
    }
    return db.prepare('SELECT * FROM articles WHERE id = ?').get(existing.id);
  }

  // Нов артикал: ако е рачно внесена шифра што сè уште не постои, се користи таа; инаку се генерира следната.
  const finalCode = code || nextArticleCode();
  const result = db
    .prepare('INSERT INTO articles (code, name, name_lower, vat_rate, type) VALUES (?, ?, ?, ?, ?)')
    .run(finalCode, name, nameLower, vat_rate === undefined || vat_rate === null ? 18 : Number(vat_rate), type);
  return db.prepare('SELECT * FROM articles WHERE id = ?').get(result.lastInsertRowid);
}

app.get('/api/articles', (req, res) => {
  const raw = (req.query.q || '').trim();
  const q = raw.toLowerCase();
  if (q) {
    // Пребарува и по назив и по шифра, за да работи автоматското пополнување и во двете полиња
    // (внесеш шифра -> ти го дава описот, внесеш опис -> ти ја дава шифрата).
    // Ако е внесен чист број, го игнорира водечките нули (внесеш "1" -> го наоѓа "00001", не мора "00001").
    let rows;
    if (/^\d+$/.test(raw)) {
      const normalized = String(parseInt(raw, 10)); // "00001" и "1" мора да се третираат исто
      rows = db
        .prepare(
          `SELECT * FROM articles WHERE CAST(CAST(code AS INTEGER) AS TEXT) LIKE ? OR name_lower LIKE ?
           ORDER BY CAST(code AS INTEGER) ASC LIMIT 15`
        )
        .all(`${normalized}%`, `%${q}%`);
    } else {
      rows = db
        .prepare('SELECT * FROM articles WHERE name_lower LIKE ? OR code LIKE ? ORDER BY name ASC LIMIT 15')
        .all(`%${q}%`, `%${q}%`);
    }
    return res.json(rows);
  }
  res.json(db.prepare('SELECT * FROM articles ORDER BY code ASC').all());
});

app.post('/api/articles', (req, res) => {
  const { name, vat_rate = 18, type = '' } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Името на артиклот е задолжително' });
  if (type && !ARTICLE_TYPES.includes(type)) return res.status(400).json({ error: 'Невалиден вид на артикал' });
  const article = upsertArticle({ name, vat_rate, type });
  res.status(201).json(article);
});

app.put('/api/articles/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM articles WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Артиклот не е пронајден' });
  const { name, vat_rate = 18, type = '' } = req.body || {};
  if (type && !ARTICLE_TYPES.includes(type)) return res.status(400).json({ error: 'Невалиден вид на артикал' });
  const finalName = name || existing.name;
  db.prepare('UPDATE articles SET name = ?, name_lower = ?, vat_rate = ?, type = ? WHERE id = ?').run(
    finalName,
    finalName.toLowerCase(),
    Number(vat_rate),
    type,
    req.params.id
  );
  res.json(db.prepare('SELECT * FROM articles WHERE id = ?').get(req.params.id));
});

// За секоја ставка се бара/создава соодветен артикал во каталогот - без разлика дали шифрата
// е рачно внесена (се користи таа) или празна (се генерира следна прогресивна) - и таа шифра
// се запишува на ставката.
function resolveItemCodes(items) {
  return items.map((item) => {
    const article = upsertArticle({ code: item.item_code, name: item.description, vat_rate: item.vat_rate });
    return { ...item, item_code: article.code };
  });
}

// Ако фирмата не е ДДВ обврзник (Поставки), задолжително сите ставки одат со 0% ДДВ,
// без разлика што е испратено од клиентот (заштита и на серверска страна, не само во UI).
function enforceVatPayerRule(items) {
  const settings = db.prepare('SELECT is_vat_payer FROM settings WHERE id = 1').get();
  if (settings && !settings.is_vat_payer) {
    return items.map((item) => ({ ...item, vat_rate: 0 }));
  }
  return items;
}

app.delete('/api/articles/:id', (req, res) => {
  db.prepare('DELETE FROM articles WHERE id = ?').run(req.params.id);
  res.status(204).end();
});

// ---- УЈП live lookup (search-as-you-type against the official registry) ----

app.get('/api/ujp/search', async (req, res) => {
  const q = (req.query.q || '').trim();
  if (q.length < 2) return res.json([]);
  try {
    const results = await searchCompanies(q);
    res.json(results);
  } catch (err) {
    res.status(502).json({ error: 'УЈП не е достапно во моментов', details: err.message });
  }
});

// Плаин преглед на податоци од УЈП, без зачувување (се користи за сопствените податоци за компанија во Поставки).
app.get('/api/ujp/details', async (req, res) => {
  const edb = (req.query.edb || '').trim();
  if (!edb) return res.status(400).json({ error: 'ЕДБ е задолжителен' });
  try {
    const details = await getCompanyDetails(edb);
    if (!details) return res.status(404).json({ error: 'Фирмата не е пронајдена во УЈП' });
    res.json(details);
  } catch (err) {
    res.status(502).json({ error: 'УЈП не е достапно во моментов', details: err.message });
  }
});

app.post('/api/clients/import-ujp', async (req, res) => {
  const { edb } = req.body || {};
  if (!edb) return res.status(400).json({ error: 'ЕДБ е задолжителен' });
  try {
    const details = await getCompanyDetails(edb);
    if (!details) return res.status(404).json({ error: 'Фирмата не е пронајдена во УЈП' });
    const client = upsertClient({
      name: details.name,
      address: details.address,
      place: details.place,
      tax_id: details.edb,
      mb: details.mb,
      phone: details.phone,
      source: 'ujp',
    });
    res.status(201).json(client);
  } catch (err) {
    res.status(502).json({ error: 'УЈП не е достапно во моментов', details: err.message });
  }
});

// ---- Invoices ----

app.get('/api/invoices', (req, res) => {
  const invoices = db
    .prepare(
      `SELECT id, invoice_number, issue_date, due_date, client_name, total, status
       FROM invoices ORDER BY id DESC`
    )
    .all();
  res.json(invoices);
});

function vatBreakdownFromItems(items) {
  const vatByRate = new Map();
  for (const item of items) {
    const entry = vatByRate.get(item.vat_rate) || { base: 0, vat: 0 };
    entry.base = round2(entry.base + item.line_net);
    entry.vat = round2(entry.vat + item.line_vat);
    vatByRate.set(item.vat_rate, entry);
  }
  return Array.from(vatByRate.entries())
    .map(([vat_rate, v]) => ({ vat_rate, base: v.base, vat: v.vat }))
    .sort((a, b) => a.vat_rate - b.vat_rate);
}

app.get('/api/invoices/:id', (req, res) => {
  const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Фактурата не е пронајдена' });

  const items = db
    .prepare('SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY id ASC')
    .all(req.params.id);

  res.json({ ...invoice, items, vatBreakdown: vatBreakdownFromItems(items) });
});

// Преземање на фактурата како PDF (се печати /print.html преку локалниот Chrome/Edge).
app.get('/api/invoices/:id/pdf', async (req, res) => {
  const invoice = db.prepare('SELECT invoice_number FROM invoices WHERE id = ?').get(req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Фактурата не е пронајдена' });

  try {
    const url = `http://127.0.0.1:${PORT}/print.html?id=${encodeURIComponent(req.params.id)}`;
    const pdf = await renderPdf(url);

    const fileName = `Фактура ${invoice.invoice_number}.pdf`;
    const asciiName = `Faktura-${invoice.invoice_number.replace(/[^\x20-\x7E]/g, '').replace(/^-+/, '') || req.params.id}.pdf`;

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Length', pdf.length);
    res.setHeader('X-File-Name', encodeURIComponent(fileName));
    res.setHeader('Access-Control-Expose-Headers', 'X-File-Name');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(fileName)}`
    );
    res.end(pdf);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

function validateInvoicePayload({ issue_date, client_name, items }) {
  if (!issue_date || !client_name || !Array.isArray(items) || items.length === 0) {
    return 'Потребни се датум на издавање, име на клиент и најмалку една ставка';
  }
  for (const item of items) {
    if (!item.description || !(Number(item.quantity) > 0) || Number(item.unit_price) < 0) {
      return 'Секоја ставка мора да има опис, количина > 0 и цена >= 0';
    }
    const discount = Number(item.discount_percent) || 0;
    if (discount < 0 || discount > 100) {
      return 'Рабатот мора да биде помеѓу 0 и 100%';
    }
    if (Number(item.vat_rate) < 0) {
      return 'ДДВ стапката на ставка не може да биде негативна';
    }
  }
  return null;
}

const round2 = (n) => Math.round(n * 100) / 100;

// Пресметува ги распределените полиња по ставка (попуст, ДДВ по стапка на ставката) и ги збирните
// износи за фактурата, вклучувајќи распределба на ДДВ по стапка (за табелата Данок/Основица/ДДВ).
function computeInvoiceTotals(items, defaultVatRate) {
  const rate = defaultVatRate === undefined || defaultVatRate === null ? 18 : Number(defaultVatRate);
  let grossAmount = 0;
  let discountAmount = 0;
  let subtotal = 0;
  let vatAmount = 0;
  const vatByRate = new Map();

  const computedItems = items.map((item) => {
    const quantity = Number(item.quantity);
    const unitPrice = Number(item.unit_price);
    const discountPercent = Number(item.discount_percent) || 0;
    const itemVatRate = item.vat_rate === undefined || item.vat_rate === null ? rate : Number(item.vat_rate);

    const gross = round2(quantity * unitPrice);
    const discount = round2(gross * (discountPercent / 100));
    const net = round2(gross - discount);
    const vat = round2(net * (itemVatRate / 100));
    const total = round2(net + vat);

    grossAmount += gross;
    discountAmount += discount;
    subtotal += net;
    vatAmount += vat;
    vatByRate.set(itemVatRate, {
      base: round2((vatByRate.get(itemVatRate)?.base || 0) + net),
      vat: round2((vatByRate.get(itemVatRate)?.vat || 0) + vat),
    });

    return {
      item_code: item.item_code || '',
      description: item.description,
      unit: item.unit || 'бр',
      quantity,
      unit_price: unitPrice,
      discount_percent: discountPercent,
      vat_rate: itemVatRate,
      line_gross: gross,
      line_discount: discount,
      line_net: net,
      line_vat: vat,
      line_total: total,
    };
  });

  const total = round2(subtotal + vatAmount);
  const vatBreakdown = Array.from(vatByRate.entries())
    .map(([vatRate, v]) => ({ vat_rate: vatRate, base: v.base, vat: v.vat }))
    .sort((a, b) => a.vat_rate - b.vat_rate);

  return {
    rate,
    grossAmount: round2(grossAmount),
    discountAmount: round2(discountAmount),
    subtotal: round2(subtotal),
    vatAmount: round2(vatAmount),
    total,
    vatBreakdown,
    computedItems,
  };
}

function replaceInvoiceItems(invoiceId, computedItems) {
  db.prepare('DELETE FROM invoice_items WHERE invoice_id = ?').run(invoiceId);
  const insertItem = db.prepare(
    `INSERT INTO invoice_items
     (invoice_id, item_code, description, unit, quantity, unit_price, discount_percent, vat_rate,
      line_gross, line_discount, line_net, line_vat, line_total)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  for (const item of computedItems) {
    insertItem.run(
      invoiceId,
      item.item_code,
      item.description,
      item.unit,
      item.quantity,
      item.unit_price,
      item.discount_percent,
      item.vat_rate,
      item.line_gross,
      item.line_discount,
      item.line_net,
      item.line_vat,
      item.line_total
    );
  }
}

app.post('/api/invoices', (req, res) => {
  const {
    issue_date,
    due_date = null,
    client_id = null,
    client_name,
    client_address = '',
    client_tax_id = '',
    client_mb = '',
    client_contact = '',
    reference = '',
    notes = '',
    vat_rate,
    items,
  } = req.body || {};

  const validationError = validateInvoicePayload({ issue_date, client_name, items });
  if (validationError) return res.status(400).json({ error: validationError });

  const itemsWithCodes = resolveItemCodes(enforceVatPayerRule(items));
  const { rate, grossAmount, discountAmount, subtotal, vatAmount, total, computedItems } = computeInvoiceTotals(itemsWithCodes, vat_rate);
  const invoiceNumber = nextInvoiceNumber();

  // Секој клиент употребен на фактура автоматски се зачувува локално,
  // за да не мора да се пребарува/внесува одново следниот пат.
  let resolvedClientId = client_id;
  if (!resolvedClientId) {
    const client = upsertClient({
      name: client_name,
      address: client_address,
      tax_id: client_tax_id,
      mb: client_mb,
      contact_name: client_contact,
      source: 'manual',
    });
    resolvedClientId = client.id;
  }

  db.exec('BEGIN');
  try {
    const result = db
      .prepare(
        `INSERT INTO invoices
         (invoice_number, issue_date, due_date, client_id, client_name, client_address, client_tax_id, client_mb,
          client_contact, reference, notes, vat_rate, gross_amount, discount_amount, subtotal, vat_amount, total, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'booked')`
      )
      .run(
        invoiceNumber,
        issue_date,
        due_date,
        resolvedClientId,
        client_name,
        client_address,
        client_tax_id,
        client_mb,
        client_contact,
        reference,
        notes,
        rate,
        grossAmount,
        discountAmount,
        subtotal,
        vatAmount,
        total
      );

    const invoiceId = result.lastInsertRowid;
    replaceInvoiceItems(invoiceId, computedItems);

    db.exec('COMMIT');
    const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(invoiceId);
    const savedItems = db.prepare('SELECT * FROM invoice_items WHERE invoice_id = ?').all(invoiceId);
    res.status(201).json({ ...invoice, items: savedItems, vatBreakdown: vatBreakdownFromItems(savedItems) });
  } catch (err) {
    db.exec('ROLLBACK');
    res.status(500).json({ error: 'Грешка при зачувување на фактурата', details: err.message });
  }
});

app.put('/api/invoices/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Фактурата не е пронајдена' });

  const {
    issue_date,
    due_date = null,
    client_id = null,
    client_name,
    client_address = '',
    client_tax_id = '',
    client_mb = '',
    client_contact = '',
    reference = '',
    notes = '',
    vat_rate,
    items,
  } = req.body || {};

  const validationError = validateInvoicePayload({ issue_date, client_name, items });
  if (validationError) return res.status(400).json({ error: validationError });

  const itemsWithCodes = resolveItemCodes(enforceVatPayerRule(items));
  const { rate, grossAmount, discountAmount, subtotal, vatAmount, total, computedItems } = computeInvoiceTotals(itemsWithCodes, vat_rate);

  let resolvedClientId = client_id;
  if (!resolvedClientId) {
    const client = upsertClient({
      name: client_name,
      address: client_address,
      tax_id: client_tax_id,
      mb: client_mb,
      contact_name: client_contact,
      source: 'manual',
    });
    resolvedClientId = client.id;
  }

  db.exec('BEGIN');
  try {
    db.prepare(
      `UPDATE invoices SET issue_date = ?, due_date = ?, client_id = ?, client_name = ?, client_address = ?,
       client_tax_id = ?, client_mb = ?, client_contact = ?, reference = ?, notes = ?, vat_rate = ?,
       gross_amount = ?, discount_amount = ?, subtotal = ?, vat_amount = ?, total = ?
       WHERE id = ?`
    ).run(
      issue_date,
      due_date,
      resolvedClientId,
      client_name,
      client_address,
      client_tax_id,
      client_mb,
      client_contact,
      reference,
      notes,
      rate,
      grossAmount,
      discountAmount,
      subtotal,
      vatAmount,
      total,
      req.params.id
    );

    replaceInvoiceItems(req.params.id, computedItems);

    db.exec('COMMIT');
    const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id);
    const savedItems = db.prepare('SELECT * FROM invoice_items WHERE invoice_id = ?').all(req.params.id);
    res.json({ ...invoice, items: savedItems, vatBreakdown: vatBreakdownFromItems(savedItems) });
  } catch (err) {
    db.exec('ROLLBACK');
    res.status(500).json({ error: 'Грешка при зачувување на фактурата', details: err.message });
  }
});

app.delete('/api/invoices/:id', (req, res) => {
  const invoice = db.prepare('SELECT id FROM invoices WHERE id = ?').get(req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Фактурата не е пронајдена' });

  db.prepare('DELETE FROM invoice_items WHERE invoice_id = ?').run(req.params.id);
  db.prepare('DELETE FROM invoices WHERE id = ?').run(req.params.id);
  res.status(204).end();
});

app.listen(PORT, () => {
  console.log(`Апликацијата работи на http://localhost:${PORT}`);
});
