/* fmt, money, escapeHtml, amountToMacedonianWords и buildInvoiceDocHtml
   се дефинирани во invoice-doc.js, кој се вчитува пред оваа датотека. */


// ---- Tabs ----
document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach((p) => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(`tab-${btn.dataset.tab}`).classList.add('active');
    if (btn.dataset.tab === 'book') loadBook();
    if (btn.dataset.tab === 'clients') loadClients();
    if (btn.dataset.tab === 'articles') loadArticles();
  });
});

// ---- New invoice: items ----
const itemsBody = document.getElementById('items-body');
const VAT_PRESETS = ['0', '5', '10', '18'];

function addItemRow(item = {}) {
  const parsedDefaultRate = Number(document.getElementById('vat_rate').value);
  const defaultVatRate = Number.isFinite(parsedDefaultRate) ? parsedDefaultRate : 18;
  const {
    item_code = '',
    description = '',
    unit = 'бр',
    quantity = 1,
    unit_price = 0,
    discount_percent = 0,
    vat_rate = defaultVatRate,
  } = item;

  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td class="col-code"><input type="text" class="item-code" value="${escapeHtml(item_code)}" /></td>
    <td><input type="text" class="item-desc" value="${escapeHtml(description)}" placeholder="Опис на услуга/производ" required /></td>
    <td class="col-unit"><input type="text" class="item-unit" value="${escapeHtml(unit)}" /></td>
    <td class="num col-qty"><input type="number" class="item-qty" value="${quantity}" min="0" step="0.01" required /></td>
    <td class="num col-price"><input type="number" class="item-price" value="${unit_price}" min="0" step="0.01" required /></td>
    <td class="num col-discount"><input type="number" class="item-discount" value="${discount_percent}" min="0" max="100" step="0.01" /></td>
    <td class="num col-vat">
      <select class="item-vat-rate" ${isVatPayer ? '' : 'disabled title="Фирмата не е ДДВ обврзник - секогаш 0%"'}>
        ${(isVatPayer ? VAT_PRESETS : ['0']).map((r) => `<option value="${r}">${r}%</option>`).join('')}
      </select>
    </td>
    <td class="num col-amount item-net">0,00</td>
    <td class="num col-amount item-line-total">0,00</td>
    <td><button type="button" class="remove-item" title="Избриши ставка">✕</button></td>
  `;
  itemsBody.appendChild(tr);

  const vatSelect = tr.querySelector('.item-vat-rate');
  vatSelect.value = isVatPayer ? (VAT_PRESETS.includes(String(vat_rate)) ? String(vat_rate) : '18') : '0';

  tr.querySelectorAll('input, select').forEach((inp) => inp.addEventListener('input', recalcTotals));
  setupItemAutocomplete(tr);
  tr.querySelector('.remove-item').addEventListener('click', () => {
    tr.remove();
    recalcTotals();
  });
  recalcTotals();
}

document.getElementById('add-item').addEventListener('click', () => addItemRow());

// ---- Article autocomplete for the "Артикал" column (one shared floating dropdown for all rows) ----
const itemSuggestions = document.getElementById('item-suggestions');
let itemSearchToken = 0;
let activeItemRow = null;

function hideItemSuggestions() {
  itemSuggestions.classList.add('hidden');
  itemSuggestions.innerHTML = '';
  activeItemRow = null;
}

function positionItemSuggestions(inputEl) {
  const rect = inputEl.getBoundingClientRect();
  itemSuggestions.style.left = `${Math.round(rect.left)}px`;
  itemSuggestions.style.top = `${Math.round(rect.bottom + 4)}px`;
  itemSuggestions.style.width = `${Math.round(Math.max(rect.width, 240))}px`;
}

function renderItemSuggestions(articles, row) {
  if (articles.length === 0) {
    itemSuggestions.innerHTML = '<div class="suggestion-item empty">Нема совпаѓања. Ќе се зачува нов артикал со нова шифра.</div>';
  } else {
    itemSuggestions.innerHTML = articles
      .map(
        (a) => `<div class="suggestion-item" data-id="${a.id}">
          ${escapeHtml(a.name)}
          <div class="sub">Шифра ${escapeHtml(a.code)} · ДДВ ${fmt.format(a.vat_rate)}%${a.type ? ' · ' + escapeHtml(a.type) : ''}</div>
        </div>`
      )
      .join('');
    itemSuggestions.querySelectorAll('.suggestion-item[data-id]').forEach((el) => {
      el.addEventListener('click', () => {
        const article = articles.find((a) => String(a.id) === el.dataset.id);
        if (article && row) {
          row.querySelector('.item-code').value = article.code;
          row.querySelector('.item-desc').value = article.name;
          const vatSelect = row.querySelector('.item-vat-rate');
          vatSelect.value = VAT_PRESETS.includes(String(article.vat_rate)) ? String(article.vat_rate) : '18';
          recalcTotals();
        }
        hideItemSuggestions();
      });
    });
  }
  itemSuggestions.classList.remove('hidden');
}

function wireArticleField(row, input, { clearCode = false } = {}) {
  let debounceTimer;
  input.addEventListener('input', () => {
    if (clearCode) row.querySelector('.item-code').value = '';
    activeItemRow = row;
    const q = input.value.trim();
    clearTimeout(debounceTimer);
    if (q.length < 2) {
      hideItemSuggestions();
      return;
    }
    debounceTimer = setTimeout(async () => {
      const token = ++itemSearchToken;
      const res = await fetch(`/api/articles?q=${encodeURIComponent(q)}`);
      const articles = await res.json();
      if (token !== itemSearchToken || activeItemRow !== row) return;
      positionItemSuggestions(input);
      renderItemSuggestions(articles, row);
    }, 300);
  });
}

// Двонасочно: пишувањето и во „Артикал" и во „Шифра" бара во каталогот и, при избор,
// ги пополнува сите поврзани полиња (шифра, опис, ДДВ %).
function setupItemAutocomplete(row) {
  wireArticleField(row, row.querySelector('.item-desc'), { clearCode: true });
  wireArticleField(row, row.querySelector('.item-code'), { clearCode: false });
}

document.addEventListener('click', (e) => {
  if (!e.target.closest('.item-code') && !e.target.closest('.item-desc') && !e.target.closest('#item-suggestions')) {
    hideItemSuggestions();
  }
});
window.addEventListener('scroll', hideItemSuggestions, true);

function readItemRows() {
  return Array.from(itemsBody.querySelectorAll('tr')).map((tr) => ({
    item_code: tr.querySelector('.item-code').value.trim(),
    description: tr.querySelector('.item-desc').value.trim(),
    unit: tr.querySelector('.item-unit').value.trim() || 'бр',
    quantity: Number(tr.querySelector('.item-qty').value) || 0,
    unit_price: Number(tr.querySelector('.item-price').value) || 0,
    discount_percent: Number(tr.querySelector('.item-discount').value) || 0,
    vat_rate: Number(tr.querySelector('.item-vat-rate').value) || 0,
  }));
}

function computeTotalsLocal(items) {
  let grossAmount = 0;
  let discountAmount = 0;
  let subtotal = 0;
  let vatAmount = 0;
  const vatByRate = new Map();

  items.forEach((it) => {
    const gross = it.quantity * it.unit_price;
    const discount = gross * (it.discount_percent / 100);
    const net = gross - discount;
    const vat = net * (it.vat_rate / 100);
    grossAmount += gross;
    discountAmount += discount;
    subtotal += net;
    vatAmount += vat;
    const entry = vatByRate.get(it.vat_rate) || { base: 0, vat: 0 };
    entry.base += net;
    entry.vat += vat;
    vatByRate.set(it.vat_rate, entry);
  });

  const vatBreakdown = Array.from(vatByRate.entries())
    .map(([vat_rate, v]) => ({ vat_rate, base: v.base, vat: v.vat }))
    .sort((a, b) => a.vat_rate - b.vat_rate);

  return { grossAmount, discountAmount, subtotal, vatAmount, total: subtotal + vatAmount, vatBreakdown };
}

function recalcTotals() {
  const items = readItemRows();
  const rows = itemsBody.querySelectorAll('tr');
  rows.forEach((tr, i) => {
    const it = items[i];
    const gross = it.quantity * it.unit_price;
    const net = gross - gross * (it.discount_percent / 100);
    const vat = net * (it.vat_rate / 100);
    tr.querySelector('.item-net').textContent = fmt.format(net);
    tr.querySelector('.item-line-total').textContent = fmt.format(net + vat);
  });

  const { grossAmount, discountAmount, subtotal, vatAmount, total, vatBreakdown } = computeTotalsLocal(items);
  document.getElementById('sum-gross').textContent = money(grossAmount);
  document.getElementById('sum-discount').textContent = money(discountAmount);
  document.getElementById('sum-subtotal').textContent = money(subtotal);
  document.getElementById('sum-vat').textContent = money(vatAmount);
  document.getElementById('sum-total').textContent = money(total);

  const breakdownEl = document.getElementById('vat-breakdown');
  if (vatBreakdown.length > 1) {
    breakdownEl.innerHTML = `
      <table>
        <thead><tr><th>Данок</th><th>Основица за ДДВ</th><th>ДДВ</th></tr></thead>
        <tbody>
          ${vatBreakdown
            .map((v) => `<tr><td>${fmt.format(v.vat_rate)}%</td><td>${money(v.base)}</td><td>${money(v.vat)}</td></tr>`)
            .join('')}
        </tbody>
      </table>`;
  } else {
    breakdownEl.innerHTML = '';
  }
}

// ---- Reusable ДДВ rate field: preset dropdown (0/5/10/18%) + "Друго..." for a custom value ----
// (Сега само за Поставки -> Стандардна ДДВ стапка; на фактурата секоја ставка си ја бира својата.)
function setupRateSelect(selectId, inputId) {
  const select = document.getElementById(selectId);
  const input = document.getElementById(inputId);
  const presets = ['0', '5', '10', '18'];

  select.addEventListener('change', () => {
    if (select.value === 'custom') {
      input.classList.remove('hidden');
      input.focus();
    } else {
      input.classList.add('hidden');
      input.value = select.value;
    }
    input.dispatchEvent(new Event('input', { bubbles: true }));
  });

  function syncFromValue(value) {
    input.value = value;
    const str = String(Number(value));
    if (presets.includes(str)) {
      select.value = str;
      input.classList.add('hidden');
    } else {
      select.value = 'custom';
      input.classList.remove('hidden');
    }
  }

  return { syncFromValue };
}

const settingsRateField = setupRateSelect('s_default_vat_rate_choice', 's_default_vat_rate');

// ---- Reusable company/client autocomplete (local saved clients + live УЈП search) ----
// Used both for the invoice "Име на клиент" field and the Settings "Име на компанија" field.
const autocompleteInstances = [];

document.addEventListener('click', (e) => {
  autocompleteInstances.forEach(({ wrap, hide }) => {
    if (!wrap.contains(e.target)) hide();
  });
});

function createAutocomplete({ inputEl, suggestionsEl, useLocalClients = false, fetchDetails, onSelect, onError }) {
  let searchToken = 0;
  let debounceTimer;

  function hide() {
    suggestionsEl.classList.add('hidden');
    suggestionsEl.innerHTML = '';
  }

  function render({ local = [], ujp = [], loading = false }) {
    const parts = [];

    if (local.length > 0) {
      parts.push('<div class="suggestion-group-label">Мои клиенти</div>');
      local.forEach((c) => {
        parts.push(
          `<div class="suggestion-item" data-source="local" data-id="${c.id}">
            ${escapeHtml(c.name)}
            <div class="sub">${escapeHtml([c.address, c.place].filter(Boolean).join(', ') || c.tax_id || '')}</div>
          </div>`
        );
      });
    }

    if (ujp.length > 0) {
      parts.push('<div class="suggestion-group-label">Од УЈП</div>');
      ujp.forEach((c) => {
        parts.push(`<div class="suggestion-item" data-source="ujp" data-edb="${escapeHtml(c.edb)}">${escapeHtml(c.name)}</div>`);
      });
    }

    if (loading) {
      parts.push('<div class="suggestion-item loading">Пребарување во УЈП…</div>');
    }

    if (!loading && local.length === 0 && ujp.length === 0) {
      parts.push('<div class="suggestion-item empty">Нема резултати. Пополнете рачно.</div>');
    }

    suggestionsEl.innerHTML = parts.join('');
    suggestionsEl.classList.remove('hidden');

    suggestionsEl.querySelectorAll('.suggestion-item[data-source="local"]').forEach((el) => {
      el.addEventListener('click', () => {
        const client = local.find((c) => String(c.id) === el.dataset.id);
        if (client) {
          onSelect(client);
          hide();
        }
      });
    });

    suggestionsEl.querySelectorAll('.suggestion-item[data-source="ujp"]').forEach((el) => {
      el.addEventListener('click', async () => {
        el.textContent = 'Преземање податоци...';
        try {
          const details = await fetchDetails(el.dataset.edb);
          onSelect(details);
        } catch (err) {
          onError(err);
        }
        hide();
      });
    });
  }

  inputEl.addEventListener('input', () => {
    const q = inputEl.value.trim();
    clearTimeout(debounceTimer);
    if (q.length < 2) {
      hide();
      return;
    }
    debounceTimer = setTimeout(async () => {
      const token = ++searchToken;
      let local = [];
      if (useLocalClients) {
        const localRes = await fetch(`/api/clients?q=${encodeURIComponent(q)}`);
        local = await localRes.json();
        if (token !== searchToken) return;
      }
      render({ local, ujp: [], loading: true });

      try {
        const ujpRes = await fetch(`/api/ujp/search?q=${encodeURIComponent(q)}`);
        const ujpAll = await ujpRes.json();
        if (token !== searchToken) return;
        const localTaxIds = new Set(local.map((c) => c.tax_id).filter(Boolean));
        const ujp = ujpAll.filter((c) => !localTaxIds.has(c.edb));
        render({ local, ujp, loading: false });
      } catch {
        if (token !== searchToken) return;
        render({ local, ujp: [], loading: false });
      }
    }, 350);
  });

  autocompleteInstances.push({ wrap: inputEl.closest('.autocomplete-wrap'), hide });
  return { hide };
}

async function importUjpAsClient(edb) {
  const res = await fetch('/api/clients/import-ujp', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ edb }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Грешка');
  return data;
}

async function fetchUjpDetails(edb) {
  const res = await fetch(`/api/ujp/details?edb=${encodeURIComponent(edb)}`);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Грешка');
  return data;
}

function fillClientFields(client) {
  document.getElementById('client_id').value = client.id || '';
  document.getElementById('client_name').value = client.name || '';
  document.getElementById('client_address').value = [client.address, client.place].filter(Boolean).join(', ');
  document.getElementById('client_tax_id').value = client.tax_id || client.edb || '';
  document.getElementById('client_mb').value = client.mb || '';
  document.getElementById('client_contact').value = client.contact_name || '';
}

createAutocomplete({
  inputEl: document.getElementById('client_name'),
  suggestionsEl: document.getElementById('client-suggestions'),
  useLocalClients: true,
  fetchDetails: importUjpAsClient,
  onSelect: fillClientFields,
  onError: (err) => {
    formMessage.textContent = err.message;
    formMessage.className = 'message error';
  },
});

document.getElementById('client_name').addEventListener('input', () => {
  document.getElementById('client_id').value = '';
});

// ---- Submit new / edited invoice ----
const form = document.getElementById('invoice-form');
const formMessage = document.getElementById('form-message');
const submitInvoiceBtn = document.getElementById('submit-invoice-btn');
const cancelEditBtn = document.getElementById('cancel-edit-btn');
let editingInvoiceId = null;

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  formMessage.textContent = '';
  formMessage.className = 'message';

  const items = readItemRows();

  if (items.length === 0) {
    formMessage.textContent = 'Додадете најмалку една ставка.';
    formMessage.className = 'message error';
    return;
  }

  const { total: previewTotal } = computeTotalsLocal(items);
  if (previewTotal <= 0) {
    const proceed = confirm(
      'Вкупниот износ на фактурата е 0,00 МКД (нема внесени количини/цени). Дали сте сигурни дека сакате да ја книжите вака?'
    );
    if (!proceed) return;
  }

  const payload = {
    issue_date: document.getElementById('issue_date').value,
    due_date: document.getElementById('due_date').value || null,
    client_id: document.getElementById('client_id').value || null,
    client_name: document.getElementById('client_name').value.trim(),
    client_address: document.getElementById('client_address').value.trim(),
    client_tax_id: document.getElementById('client_tax_id').value.trim(),
    client_mb: document.getElementById('client_mb').value.trim(),
    client_contact: document.getElementById('client_contact').value.trim(),
    reference: document.getElementById('reference').value.trim(),
    notes: document.getElementById('notes').value.trim(),
    vat_rate: Number(document.getElementById('vat_rate').value),
    items,
  };

  try {
    const url = editingInvoiceId ? `/api/invoices/${editingInvoiceId}` : '/api/invoices';
    const method = editingInvoiceId ? 'PUT' : 'POST';
    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Грешка при зачувување');

    formMessage.textContent = editingInvoiceId
      ? `Фактура ${data.invoice_number} е ажурирана.`
      : `Фактура ${data.invoice_number} е зачувана и книжена.`;
    formMessage.className = 'message';
    resetForm();
    openInvoiceModal(data.id);
  } catch (err) {
    formMessage.textContent = err.message;
    formMessage.className = 'message error';
  }
});

function setEditingMode(invoiceId) {
  editingInvoiceId = invoiceId;
  submitInvoiceBtn.textContent = invoiceId ? 'Зачувај промени' : 'Зачувај и книжи';
  cancelEditBtn.classList.toggle('hidden', !invoiceId);
}

cancelEditBtn.addEventListener('click', () => {
  resetForm();
  formMessage.textContent = '';
});

async function startEditInvoice(id) {
  const res = await fetch(`/api/invoices/${id}`);
  const inv = await res.json();
  if (!res.ok) return;

  document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach((p) => p.classList.remove('active'));
  document.querySelector('.tab-btn[data-tab="new"]').classList.add('active');
  document.getElementById('tab-new').classList.add('active');

  document.getElementById('issue_date').value = inv.issue_date;
  document.getElementById('due_date').value = inv.due_date || '';
  dueDateManuallySet = true; // не го препишувај веќе зачуваниот датум на доспевање автоматски
  document.getElementById('vat_rate').value = inv.vat_rate;
  document.getElementById('client_id').value = inv.client_id || '';
  document.getElementById('client_name').value = inv.client_name || '';
  document.getElementById('client_address').value = inv.client_address || '';
  document.getElementById('client_tax_id').value = inv.client_tax_id || '';
  document.getElementById('client_mb').value = inv.client_mb || '';
  document.getElementById('client_contact').value = inv.client_contact || '';
  document.getElementById('reference').value = inv.reference || '';
  document.getElementById('notes').value = inv.notes || '';

  itemsBody.innerHTML = '';
  inv.items.forEach((it) => addItemRow(it));
  recalcTotals();

  setEditingMode(inv.id);
  formMessage.textContent = `Ја уредувате фактура ${inv.invoice_number}.`;
  formMessage.className = 'message';
}

function resetForm() {
  form.reset();
  itemsBody.innerHTML = '';
  addItemRow();
  document.getElementById('issue_date').value = todayISO();
  dueDateManuallySet = false;
  document.getElementById('due_date').value = addDays(todayISO(), 15);
  loadSettingsDefaults();
  setEditingMode(null);
}

function todayISO() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

// Пресметка на датум без UTC-конверзија на toISOString (за да не се измести за еден ден
// во зависност од временската зона).
function addDays(dateStr, days) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  date.setDate(date.getDate() + days);
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

// ---- Автоматски рок на плаќање: "Датум на доспевање" = "Датум на издавање" + 15 дена,
// освен ако корисникот рачно не го смени датумот на доспевање. ----
let dueDateManuallySet = false;

document.getElementById('due_date').addEventListener('input', () => {
  dueDateManuallySet = true;
});

document.getElementById('issue_date').addEventListener('input', () => {
  if (dueDateManuallySet) return;
  const issueDate = document.getElementById('issue_date').value;
  if (issueDate) {
    document.getElementById('due_date').value = addDays(issueDate, 15);
  }
});

// ---- Book / ledger ----
let allBookInvoices = [];

async function loadBook() {
  const res = await fetch('/api/invoices');
  allBookInvoices = await res.json();
  document.getElementById('book-search').value = '';
  renderBookTable(allBookInvoices);
}

// Совпаѓа по цел или дел од бројот на фактура, по клиент, или по чист број од секвенцата
// (внесеш "252" -> го наоѓа "ФАК-2026-0252", без разлика на водечките нули).
function invoiceMatchesQuery(inv, rawQuery) {
  const trimmed = rawQuery.trim();
  const q = trimmed.toLowerCase();
  if (!q) return true;
  if (inv.invoice_number.toLowerCase().includes(q)) return true;
  if (inv.client_name.toLowerCase().includes(q)) return true;
  if (/^\d+$/.test(trimmed)) {
    const parts = inv.invoice_number.split('-');
    const seq = parseInt(parts[parts.length - 1], 10);
    if (!Number.isNaN(seq) && seq === parseInt(trimmed, 10)) return true;
  }
  return false;
}

function renderBookTable(invoices, highlightQuery = '') {
  const tbody = document.getElementById('book-body');

  if (invoices.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" class="empty">${
      highlightQuery ? 'Нема фактура што одговара на пребарувањето.' : 'Нема книжени фактури.'
    }</td></tr>`;
    return;
  }

  tbody.innerHTML = '';
  invoices.forEach((inv) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${escapeHtml(inv.invoice_number)}</td>
      <td>${escapeHtml(inv.issue_date)}</td>
      <td>${escapeHtml(inv.client_name)}</td>
      <td class="num">${money(inv.total)}</td>
      <td><span class="status-pill">книжена</span></td>
      <td><button type="button" class="link-btn pdf-btn">PDF</button></td>
      <td><button type="button" class="link-btn edit-btn">Уреди</button></td>
      <td><button type="button" class="link-btn delete-btn">Избриши</button></td>
    `;
    tr.addEventListener('click', (e) => {
      if (e.target.closest('.link-btn')) return;
      openInvoiceModal(inv.id);
    });
    tr.querySelector('.pdf-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      downloadInvoicePdf(inv.id, e.currentTarget);
    });
    tr.querySelector('.edit-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      startEditInvoice(inv.id);
    });
    tr.querySelector('.delete-btn').addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!confirm(`Да се избрише фактура ${inv.invoice_number}?`)) return;
      await fetch(`/api/invoices/${inv.id}`, { method: 'DELETE' });
      loadBook();
    });
    tbody.appendChild(tr);
  });

  // Ако пребарувањето погоди точно една фактура, ја истакнуваме и скролуваме до неа -
  // "право таму" наместо само да ја филтрираме листата.
  if (highlightQuery && invoices.length === 1) {
    const row = tbody.querySelector('tr');
    row.classList.add('search-highlight');
    row.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
}

function runBookSearch() {
  const q = document.getElementById('book-search').value;
  const filtered = allBookInvoices.filter((inv) => invoiceMatchesQuery(inv, q));
  renderBookTable(filtered, q);
}

document.getElementById('book-search').addEventListener('input', runBookSearch);
document.getElementById('book-search-btn').addEventListener('click', runBookSearch);
document.getElementById('book-search').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    runBookSearch();
  }
});

// ---- Invoice modal / print / PDF ----
const modal = document.getElementById('invoice-modal');
const printArea = document.getElementById('invoice-print-area');
let currentInvoiceId = null;

// Го поставува логото да ја има истата висина/ширина како блокот со податоци за фирмата
// (име, адреса, тел, ЕДБ, сметка), за да изгледаат симетрично едно до друго во заглавието.
function syncLogoSizeToIssuerText() {
  const logo = printArea.querySelector('.doc-logo');
  const issuer = printArea.querySelector('.doc-issuer');
  if (!logo || !issuer) return;
  const textCol = issuer.querySelector(':scope > div:last-child');
  if (!textCol) return;

  logo.style.width = '';
  logo.style.height = '';
  const textHeight = textCol.getBoundingClientRect().height;
  const size = Math.round(Math.min(160, Math.max(70, textHeight)));
  logo.style.width = `${size}px`;
  logo.style.height = `${size}px`;
}

async function openInvoiceModal(id) {
  const [invRes, settingsRes] = await Promise.all([
    fetch(`/api/invoices/${id}`),
    fetch('/api/settings'),
  ]);
  const inv = await invRes.json();
  const settings = await settingsRes.json();
  currentInvoiceId = id;
  printArea.innerHTML = buildInvoiceDocHtml(inv, settings);

  modal.classList.remove('hidden');
  syncLogoSizeToIssuerText();
}

// Го презема PDF-от што серверот го генерира од истиот изглед на фактурата.
async function downloadInvoicePdf(id, btn) {
  const label = btn ? btn.textContent : '';
  if (btn) { btn.disabled = true; btn.textContent = 'Се подготвува...'; }
  try {
    const res = await fetch(`/api/invoices/${id}/pdf`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Не успеа генерирањето на PDF');
    }
    const blob = await res.blob();
    const name = decodeURIComponent((res.headers.get('X-File-Name') || `Фактура-${id}.pdf`));
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  } catch (err) {
    alert(err.message);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = label; }
  }
}

document.getElementById('close-modal').addEventListener('click', () => modal.classList.add('hidden'));
document.getElementById('print-invoice').addEventListener('click', () => window.print());
document.getElementById('pdf-invoice').addEventListener('click', (e) => {
  if (currentInvoiceId) downloadInvoicePdf(currentInvoiceId, e.currentTarget);
});
window.addEventListener('beforeprint', syncLogoSizeToIssuerText);
modal.addEventListener('click', (e) => {
  if (e.target === modal) modal.classList.add('hidden');
});

// ---- Settings ----
const settingsForm = document.getElementById('settings-form');
const settingsMessage = document.getElementById('settings-message');

let isVatPayer = true;

async function loadSettingsDefaults() {
  const res = await fetch('/api/settings');
  const s = await res.json();
  isVatPayer = !!s.is_vat_payer;
  document.getElementById('vat_rate').value = isVatPayer ? s.default_vat_rate : 0;
  recalcTotals();
}

let currentLogo = '';

function setLogoPreview(dataUrl) {
  currentLogo = dataUrl || '';
  const preview = document.getElementById('logo-preview');
  const removeBtn = document.getElementById('remove-logo');
  if (currentLogo) {
    preview.innerHTML = `<img src="${currentLogo}" alt="Лого" />`;
    preview.classList.add('has-logo');
    removeBtn.classList.remove('hidden');
  } else {
    preview.innerHTML = `
      <span class="logo-placeholder-icon">🖼️</span>
      <span>Без лого</span>
    `;
    preview.classList.remove('has-logo');
    removeBtn.classList.add('hidden');
  }
}

document.getElementById('s_company_logo_file').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => setLogoPreview(reader.result);
  reader.readAsDataURL(file);
});

document.getElementById('remove-logo').addEventListener('click', () => {
  setLogoPreview('');
  document.getElementById('s_company_logo_file').value = '';
});

async function loadSettingsForm() {
  const res = await fetch('/api/settings');
  const s = await res.json();
  document.getElementById('s_company_name').value = s.company_name || '';
  document.getElementById('s_company_address').value = s.company_address || '';
  document.getElementById('s_company_tax_id').value = s.company_tax_id || '';
  document.getElementById('s_company_phone').value = s.company_phone || '';
  document.getElementById('s_company_bank_account').value = s.company_bank_account || '';
  document.getElementById('s_company_bank_name').value = s.company_bank_name || '';
  document.getElementById('s_payment_terms_note').value = s.payment_terms_note || '';
  setLogoPreview(s.company_logo || '');
  settingsRateField.syncFromValue(s.default_vat_rate);
  document.getElementById('s_is_vat_payer').checked = !!s.is_vat_payer;
  applyVatPayerUiState(!!s.is_vat_payer);
}

// Кога фирмата не е ДДВ обврзник, стандардната стапка во Поставки нема смисла - ја заклучуваме на 0%.
function applyVatPayerUiState(vatPayer) {
  const select = document.getElementById('s_default_vat_rate_choice');
  const input = document.getElementById('s_default_vat_rate');
  select.disabled = !vatPayer;
  input.disabled = !vatPayer;
  if (!vatPayer) {
    settingsRateField.syncFromValue(0);
  }
}

document.getElementById('s_is_vat_payer').addEventListener('change', (e) => {
  applyVatPayerUiState(e.target.checked);
});

function fillCompanyFields(details) {
  document.getElementById('s_company_name').value = details.name || '';
  document.getElementById('s_company_address').value = [details.address, details.place].filter(Boolean).join(', ');
  document.getElementById('s_company_tax_id').value = details.edb || details.tax_id || '';
  if (details.phone) {
    document.getElementById('s_company_phone').value = details.phone;
  }
  if (details.giro_account) {
    document.getElementById('s_company_bank_account').value = details.giro_account;
  }
  if (details.depository_bank) {
    document.getElementById('s_company_bank_name').value = details.depository_bank;
  }
}

createAutocomplete({
  inputEl: document.getElementById('s_company_name'),
  suggestionsEl: document.getElementById('company-suggestions'),
  useLocalClients: false,
  fetchDetails: fetchUjpDetails,
  onSelect: fillCompanyFields,
  onError: (err) => {
    settingsMessage.textContent = err.message;
    settingsMessage.className = 'message error';
  },
});

settingsForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    company_name: document.getElementById('s_company_name').value.trim(),
    company_address: document.getElementById('s_company_address').value.trim(),
    company_tax_id: document.getElementById('s_company_tax_id').value.trim(),
    company_phone: document.getElementById('s_company_phone').value.trim(),
    company_bank_account: document.getElementById('s_company_bank_account').value.trim(),
    company_bank_name: document.getElementById('s_company_bank_name').value.trim(),
    company_logo: currentLogo,
    payment_terms_note: document.getElementById('s_payment_terms_note').value.trim(),
    default_vat_rate: Number(document.getElementById('s_default_vat_rate').value),
    is_vat_payer: document.getElementById('s_is_vat_payer').checked,
  };
  const res = await fetch('/api/settings', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (res.ok) {
    isVatPayer = payload.is_vat_payer;
    settingsMessage.textContent = 'Поставките се зачувани.';
    settingsMessage.className = 'message';
  } else {
    settingsMessage.textContent = 'Грешка при зачувување.';
    settingsMessage.className = 'message error';
  }
});

// ---- Clients tab ----
let allClients = [];

async function loadClients() {
  const res = await fetch('/api/clients');
  allClients = await res.json();
  document.getElementById('client-search').value = '';
  renderClientsTable(allClients);
}

function clientMatchesQuery(c, rawQuery) {
  const q = rawQuery.trim().toLowerCase();
  if (!q) return true;
  if (c.name.toLowerCase().includes(q)) return true;
  if ((c.tax_id || '').toLowerCase().includes(q)) return true;
  if ((c.mb || '').toLowerCase().includes(q)) return true;
  return false;
}

function renderClientsTable(clients, highlightQuery = '') {
  const tbody = document.getElementById('clients-body');

  if (clients.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10" class="empty">${
      highlightQuery ? 'Нема клиент што одговара на пребарувањето.' : 'Нема зачувани клиенти.'
    }</td></tr>`;
    return;
  }

  tbody.innerHTML = '';
  clients.forEach((c) => {
    const tr = document.createElement('tr');
    tr.dataset.clientId = c.id;
    tr.innerHTML = `
      <td>${escapeHtml(c.name)}</td>
      <td>${escapeHtml([c.address, c.place].filter(Boolean).join(', '))}</td>
      <td>${escapeHtml(c.tax_id || '')}</td>
      <td>${escapeHtml(c.mb || '')}</td>
      <td>${escapeHtml(c.phone || '')}</td>
      <td>${escapeHtml(c.email || '')}</td>
      <td>${escapeHtml(c.contact_name || '')}</td>
      <td>${escapeHtml(c.contact_phone || '')}</td>
      <td><button type="button" class="link-btn edit-client">Уреди</button></td>
      <td><button type="button" class="link-btn delete-client">Избриши</button></td>
    `;
    tr.querySelector('.edit-client').addEventListener('click', () => openClientModal(c));
    tr.querySelector('.delete-client').addEventListener('click', async () => {
      if (!confirm(`Да се избрише клиентот "${c.name}"? Ова нема да влијае на веќе издадените фактури.`)) return;
      await fetch(`/api/clients/${c.id}`, { method: 'DELETE' });
      loadClients();
    });
    tbody.appendChild(tr);
  });

  if (highlightQuery && clients.length === 1) {
    const row = tbody.querySelector('tr');
    row.classList.add('search-highlight');
    row.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
}

function runClientSearch() {
  const q = document.getElementById('client-search').value;
  const filtered = allClients.filter((c) => clientMatchesQuery(c, q));
  renderClientsTable(filtered, q);
}

document.getElementById('client-search').addEventListener('input', runClientSearch);
document.getElementById('client-search-btn').addEventListener('click', runClientSearch);
document.getElementById('client-search').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    runClientSearch();
  }
});

const clientModal = document.getElementById('client-modal');
const clientForm = document.getElementById('client-form');

function openClientModal(client = null) {
  document.getElementById('client-modal-title').textContent = client ? 'Уреди клиент' : 'Нов клиент';
  document.getElementById('cf_id').value = client?.id || '';
  document.getElementById('cf_name').value = client?.name || '';
  document.getElementById('cf_tax_id').value = client?.tax_id || '';
  document.getElementById('cf_address').value = client ? [client.address, client.place].filter(Boolean).join(', ') : '';
  document.getElementById('cf_mb').value = client?.mb || '';
  document.getElementById('cf_phone').value = client?.phone || '';
  document.getElementById('cf_email').value = client?.email || '';
  document.getElementById('cf_contact_name').value = client?.contact_name || '';
  document.getElementById('cf_contact_phone').value = client?.contact_phone || '';
  clientModal.classList.remove('hidden');
}

document.getElementById('add-client').addEventListener('click', () => openClientModal());
document.getElementById('close-client-modal').addEventListener('click', () => clientModal.classList.add('hidden'));
clientModal.addEventListener('click', (e) => {
  if (e.target === clientModal) clientModal.classList.add('hidden');
});

clientForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('cf_id').value;
  const payload = {
    name: document.getElementById('cf_name').value.trim(),
    address: document.getElementById('cf_address').value.trim(),
    tax_id: document.getElementById('cf_tax_id').value.trim(),
    mb: document.getElementById('cf_mb').value.trim(),
    phone: document.getElementById('cf_phone').value.trim(),
    email: document.getElementById('cf_email').value.trim(),
    contact_name: document.getElementById('cf_contact_name').value.trim(),
    contact_phone: document.getElementById('cf_contact_phone').value.trim(),
  };
  const res = await fetch(id ? `/api/clients/${id}` : '/api/clients', {
    method: id ? 'PUT' : 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const savedClient = await res.json();
  clientModal.classList.add('hidden');
  await loadClients();
  if (savedClient && savedClient.id) highlightClientRow(savedClient.id);
});

function highlightClientRow(clientId) {
  const row = document.querySelector(`#clients-body tr[data-client-id="${clientId}"]`);
  if (row) {
    row.classList.add('search-highlight');
    row.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
}

// ---- Articles tab ----
let allArticles = [];

async function loadArticles() {
  const res = await fetch('/api/articles');
  allArticles = await res.json();
  document.getElementById('article-search').value = '';
  renderArticlesTable(allArticles);
}

// Совпаѓа по назив или шифра; ако е внесен чист број, ги игнорира водечките нули
// (внесеш "1" -> го наоѓа "00001"), исто како пребарувањето при внес во фактура.
function articleMatchesQuery(a, rawQuery) {
  const trimmed = rawQuery.trim();
  const q = trimmed.toLowerCase();
  if (!q) return true;
  if (a.name.toLowerCase().includes(q)) return true;
  if (a.code.toLowerCase().includes(q)) return true;
  if (/^\d+$/.test(trimmed)) {
    const codeNum = parseInt(a.code, 10);
    if (!Number.isNaN(codeNum) && String(codeNum).startsWith(String(parseInt(trimmed, 10)))) return true;
  }
  return false;
}

function renderArticlesTable(articles, highlightQuery = '') {
  const tbody = document.getElementById('articles-body');

  if (articles.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="empty">${
      highlightQuery ? 'Нема артикал што одговара на пребарувањето.' : 'Нема зачувани артикли.'
    }</td></tr>`;
    return;
  }

  tbody.innerHTML = '';
  articles.forEach((a) => {
    const tr = document.createElement('tr');
    tr.dataset.articleId = a.id;
    tr.innerHTML = `
      <td>${escapeHtml(a.code)}</td>
      <td>${escapeHtml(a.name)}</td>
      <td class="num">${fmt.format(a.vat_rate)}%</td>
      <td>${escapeHtml(a.type || '')}</td>
      <td><button type="button" class="link-btn edit-article">Уреди</button></td>
      <td><button type="button" class="link-btn delete-article">Избриши</button></td>
    `;
    tr.querySelector('.edit-article').addEventListener('click', () => openArticleModal(a));
    tr.querySelector('.delete-article').addEventListener('click', async () => {
      if (!confirm(`Да се избрише артиклот "${a.name}" (${a.code})? Ова нема да влијае на веќе издадените фактури.`)) return;
      await fetch(`/api/articles/${a.id}`, { method: 'DELETE' });
      loadArticles();
    });
    tbody.appendChild(tr);
  });

  if (highlightQuery && articles.length === 1) {
    const row = tbody.querySelector('tr');
    row.classList.add('search-highlight');
    row.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
}

function runArticleSearch() {
  const q = document.getElementById('article-search').value;
  const filtered = allArticles.filter((a) => articleMatchesQuery(a, q));
  renderArticlesTable(filtered, q);
}

document.getElementById('article-search').addEventListener('input', runArticleSearch);
document.getElementById('article-search-btn').addEventListener('click', runArticleSearch);
document.getElementById('article-search').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    runArticleSearch();
  }
});

const articleModal = document.getElementById('article-modal');
const articleForm = document.getElementById('article-form');

function openArticleModal(article = null) {
  document.getElementById('article-modal-title').textContent = article ? 'Уреди артикал' : 'Нов артикал';
  document.getElementById('af_id').value = article?.id || '';
  document.getElementById('af_code').value = article ? article.code : 'се генерира автоматски';
  document.getElementById('af_name').value = article?.name || '';
  document.getElementById('af_vat_rate').value = VAT_PRESETS.includes(String(article?.vat_rate)) ? String(article.vat_rate) : '18';
  document.getElementById('af_type').value = article?.type || '';
  articleModal.classList.remove('hidden');
}

document.getElementById('add-article').addEventListener('click', () => openArticleModal());
document.getElementById('close-article-modal').addEventListener('click', () => articleModal.classList.add('hidden'));
articleModal.addEventListener('click', (e) => {
  if (e.target === articleModal) articleModal.classList.add('hidden');
});

articleForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('af_id').value;
  const payload = {
    name: document.getElementById('af_name').value.trim(),
    vat_rate: Number(document.getElementById('af_vat_rate').value),
    type: document.getElementById('af_type').value,
  };
  const res = await fetch(id ? `/api/articles/${id}` : '/api/articles', {
    method: id ? 'PUT' : 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const saved = await res.json();
  articleModal.classList.add('hidden');
  await loadArticles();
  // Насочи право до новододадениот/уредениот артикал во табелата, за да се потврди дека е внесен.
  if (saved && saved.id) highlightArticleRow(saved.id);
});

function highlightArticleRow(articleId) {
  const row = document.querySelector(`#articles-body tr[data-article-id="${articleId}"]`);
  if (row) {
    row.classList.add('search-highlight');
    row.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
}

// ---- Init ----
document.getElementById('issue_date').value = todayISO();
document.getElementById('due_date').value = addDays(todayISO(), 15);
loadSettingsDefaults().then(() => addItemRow());
loadSettingsForm();
